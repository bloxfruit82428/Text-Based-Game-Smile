import random
import pickle

# Define the player class
class Player:
    def __init__(self, name):
        self.name = name
        self.health = 100
        self.sanity = 100
        self.inventory = []
        self.xp = 0
        self.level = 1
        self.damage = 10

    def is_alive(self):
        return self.health > 0 and self.sanity > 0

    def add_item(self, item):
        self.inventory.append(item)
        print(f"You found a {item}!")

    def use_item(self, item):
        if item in self.inventory:
            self.inventory.remove(item)
            if item == "health potion":
                self.health += 20
                print("You used a health potion and restored 20 health!")
            elif item == "sanity potion":
                self.sanity += 20
                print("You used a sanity potion and restored 20 sanity!")
        else:
            print("You don't have that item!")

    def gain_xp(self, amount):
        self.xp += amount
        print(f"You gained {amount} XP!")
        if self.xp >= self.level * 100:
            self.level_up()

    def level_up(self):
        self.level += 1
        self.damage += 5
        self.health += 20
        self.sanity += 20
        print(f"Congratulations! You leveled up to level {self.level}!")
        print(f"Your damage increased to {self.damage}, health to {self.health}, and sanity to {self.sanity}.")

# Define the enemy class
class Enemy:
    def __init__(self, name, health, damage, xp_reward):
        self.name = name
        self.health = health
        self.damage = damage
        self.xp_reward = xp_reward

# Define the game class
class Game:
    def __init__(self, player):
        self.player = player
        self.level = 1
        self.enemies = [
            Enemy("Smiling Entity", 50, 10, 50),
            Enemy("Haunted Doll", 70, 15, 70),
            Enemy("Cursed Spirit", 100, 20, 100)
        ]

    def encounter(self):
        enemy = random.choice(self.enemies)
        print(f"\nYou encounter a {enemy.name}!")
        action = input("Do you want to (1) Run, (2) Confront it, (3) Use an item, or (4) Save game? ")
        if action == "1":
            self.run_away()
        elif action == "2":
            self.confront_enemy(enemy)
        elif action == "3":
            self.use_item()
        elif action == "4":
            self.save_game()
        else:
            print("Invalid choice. The enemy attacks you!")
            self.player.health -= enemy.damage

    def run_away(self):
        print("You try to run away...")
        if random.choice([True, False]):
            print("You successfully escaped!")
        else:
            print("The enemy catches you and drains your sanity!")
            self.player.sanity -= 20

    def confront_enemy(self, enemy):
        print(f"You confront the {enemy.name}...")
        if random.choice([True, False]):
            print(f"You manage to fend off the {enemy.name}!")
            self.player.gain_xp(enemy.xp_reward)
        else:
            print(f"The {enemy.name} overpowers you and drains your health!")
            self.player.health -= enemy.damage

    def use_item(self):
        if not self.player.inventory:
            print("You have no items to use!")
            return
        print(f"Inventory: {self.player.inventory}")
        item = input("Which item do you want to use? ")
        self.player.use_item(item)

    def find_item(self):
        items = ["health potion", "sanity potion"]
        found_item = random.choice(items)
        self.player.add_item(found_item)

    def save_game(self):
        with open('savegame.pkl', 'wb') as f:
            pickle.dump(self.player, f)
        print("Game saved successfully!")

    def load_game(self):
        try:
            with open('savegame.pkl', 'rb') as f:
                self.player = pickle.load(f)
            print("Game loaded successfully!")
        except FileNotFoundError:
            print("No saved game found.")

    def play(self):
        print(f"Welcome to the Smile RPG, {self.player.name}!")
        while self.player.is_alive():
            if random.choice([True, False]):
                self.find_item()
            self.encounter()
            print(f"Health: {self.player.health}, Sanity: {self.player.sanity}, Inventory: {self.player.inventory}, XP: {self.player.xp}, Level: {self.player.level}, Damage: {self.player.damage}")
        self.end_game()

    def end_game(self):
        if self.player.health <= 0:
            print("You have been defeated by the entity. Game Over.")
        elif self.player.sanity <= 0:
            print("You have lost your sanity. Game Over.")
        else:
            print("Congratulations! You have survived the horrors and emerged victorious!")

# Main game loop
if __name__ == "__main__":
    choice = input("Do you want to (1) Start a new game or (2) Load a saved game? ")
    if choice == "1":
        player_name = input("Enter your name: ")
        player = Player(player_name)
    elif choice == "2":
        game = Game(None)
        game.load_game()
        player = game.player
    else:
        print("Invalid choice. Starting a new game.")
        player_name = input("Enter your name: ")
        player = Player(player_name)

    game = Game(player)
    game.play()
